
-- Données de test : 10 entreprises
INSERT INTO entreprise (nom, date_creation) VALUES
('Entreprise Alpha', '2015-03-10'),
('Entreprise Beta', '2016-06-22'),
('Entreprise Gamma', '2017-09-13'),
('Entreprise Delta', '2018-12-04'),
('Entreprise Epsilon', '2019-01-19'),
('Entreprise Zeta', '2020-02-11'),
('Entreprise Eta', '2021-03-17'),
('Entreprise Theta', '2022-04-25'),
('Entreprise Iota', '2023-05-03'),
('Entreprise Kappa', '2024-01-30');

-- Un questionnaire générique
INSERT INTO questionnaire (nom, date_creation, actif) VALUES
('Questionnaire RSE 2023', '2023-06-01', TRUE);

-- Catégories
INSERT INTO categorie (nom) VALUES
('Agroalimentaire'),
('Environnement'),
('Gouvernance');

-- Questions associées aux catégories
INSERT INTO question (texte, categorie_id) VALUES
('Votre entreprise utilise-t-elle des emballages recyclables ?', 2),
('Avez-vous une politique de recyclage ?', 2),
('Votre entreprise respecte-t-elle les normes ISO ?', 3),
('Travaillez-vous avec des fournisseurs locaux ?', 1);

-- Réponses possibles (radio)
INSERT INTO reponse_possibles (question_id, texte, points) VALUES
(1, 'Oui', 10),
(1, 'Non', 0),
(2, 'Oui', 10),
(2, 'Non', 0),
(3, 'Oui', 15),
(3, 'Non', 0),
(4, 'Toujours', 10),
(4, 'Parfois', 5),
(4, 'Jamais', 0);

-- Historique des réponses pour 6 entreprises (4 non à jour)
INSERT INTO questionnaire_entreprise (entreprise_id, questionnaire_id, date_realisation, note_finale, nbr_jours, date_echeance, alerte_envoyee) VALUES
(1, 1, '2021-05-01', 30, DATEDIFF(CURDATE(), '2021-05-01'), DATE_ADD('2021-05-01', INTERVAL 2 YEAR), TRUE),
(2, 1, '2024-06-01', 25, DATEDIFF(CURDATE(), '2024-06-01'), DATE_ADD('2024-06-01', INTERVAL 2 YEAR), FALSE),
(3, 1, '2022-03-15', 20, DATEDIFF(CURDATE(), '2022-03-15'), DATE_ADD('2022-03-15', INTERVAL 2 YEAR), TRUE),
(5, 1, '2023-07-10', 15, DATEDIFF(CURDATE(), '2023-07-10'), DATE_ADD('2023-07-10', INTERVAL 2 YEAR), FALSE),
(6, 1, '2021-02-28', 35, DATEDIFF(CURDATE(), '2021-02-28'), DATE_ADD('2021-02-28', INTERVAL 2 YEAR), TRUE),
(8, 1, '2023-11-20', 28, DATEDIFF(CURDATE(), '2023-11-20'), DATE_ADD('2023-11-20', INTERVAL 2 YEAR), FALSE);
