
-- Création des tables pour l'outil RSE

CREATE TABLE entreprise (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    date_creation DATE
);

CREATE TABLE questionnaire (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    date_creation DATE,
    actif BOOLEAN DEFAULT TRUE
);

CREATE TABLE categorie (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL
);

CREATE TABLE question (
    id INT PRIMARY KEY AUTO_INCREMENT,
    texte TEXT NOT NULL,
    categorie_id INT,
    FOREIGN KEY (categorie_id) REFERENCES categorie(id)
);

CREATE TABLE reponse_possibles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question_id INT,
    texte VARCHAR(255),
    points INT,
    FOREIGN KEY (question_id) REFERENCES question(id)
);

CREATE TABLE questionnaire_entreprise (
    id INT PRIMARY KEY AUTO_INCREMENT,
    entreprise_id INT,
    questionnaire_id INT,
    date_realisation DATE,
    note_finale INT,
    nbr_jours INT,  -- Nombre de jours depuis la dernière réalisation
    date_echeance DATE,  -- Date limite des 2 ans
    alerte_envoyee BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (entreprise_id) REFERENCES entreprise(id),
    FOREIGN KEY (questionnaire_id) REFERENCES questionnaire(id)
);

CREATE TABLE reponse_entreprise (
    id INT PRIMARY KEY AUTO_INCREMENT,
    questionnaire_entreprise_id INT,
    question_id INT,
    reponse_possibles_id INT,
    commentaire TEXT,
    FOREIGN KEY (questionnaire_entreprise_id) REFERENCES questionnaire_entreprise(id),
    FOREIGN KEY (question_id) REFERENCES question(id),
    FOREIGN KEY (reponse_possibles_id) REFERENCES reponse_possibles(id)
);


-- 📊 Requête 1 : Entreprises à relancer (pas de questionnaire depuis > 2 ans)
SELECT e.nom, MAX(qe.date_realisation) AS derniere_realisation,
       DATEDIFF(CURDATE(), MAX(qe.date_realisation)) AS jours_depuis,
       DATE_ADD(MAX(qe.date_realisation), INTERVAL 2 YEAR) AS date_echeance
FROM entreprise e
LEFT JOIN questionnaire_entreprise qe ON e.id = qe.entreprise_id
GROUP BY e.id
HAVING jours_depuis >= 700 OR MAX(qe.date_realisation) IS NULL;

-- 📊 Requête 2 : Moyenne des notes finales par entreprise
SELECT e.nom, AVG(qe.note_finale) AS moyenne_note
FROM entreprise e
JOIN questionnaire_entreprise qe ON e.id = qe.entreprise_id
GROUP BY e.id;

-- 📊 Requête 3 : Nombre de questionnaires réalisés par entreprise
SELECT e.nom, COUNT(qe.id) AS nb_questionnaires_realises
FROM entreprise e
LEFT JOIN questionnaire_entreprise qe ON e.id = qe.entreprise_id
GROUP BY e.id;
